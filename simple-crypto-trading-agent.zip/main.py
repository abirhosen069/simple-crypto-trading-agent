# main.py
import yaml
import argparse
from exchange import ExchangeClient
from strategy import SMACrossover
from utils import setup_logger

logger = setup_logger(__name__)

def load_config(path='config.yaml'):
    with open(path, 'r') as f:
        return yaml.safe_load(f)

def run(config_path='config.yaml'):
    cfg = load_config(config_path)
    ex = ExchangeClient(cfg)
    strat = SMACrossover(cfg['strategy']['fast_period'], cfg['strategy']['slow_period'])
    symbol = cfg.get('symbol')
    timeframe = cfg.get('timeframe', '1m')

    logger.info('Starting agent in %s mode for %s', cfg.get('mode'), symbol)

    while True:
        try:
            ohlcv = ex.fetch_ohlcv(symbol, timeframe=timeframe, limit=cfg['strategy']['slow_period'] + 5)
            df = strat.compute(ohlcv)
            sig = strat.signal(df)

            logger.info('Signal: %s | Last close: %s', sig, df.iloc[-1]['close'])

            if cfg.get('mode') == 'live':
                amount = cfg.get('amount')
                if sig == 'buy':
                    logger.info('Placing market buy for %s', amount)
                    res = ex.create_market_buy(symbol, amount)
                    logger.info('Order result: %s', res)
                elif sig == 'sell':
                    logger.info('Placing market sell for %s', amount)
                    res = ex.create_market_sell(symbol, amount)
                    logger.info('Order result: %s', res)

            ex.sleep(30)
        except KeyboardInterrupt:
            logger.info('Stopping agent')
            break
        except Exception as e:
            logger.exception('Error in main loop: %s', e)
            ex.sleep(5)

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--config', default='config.yaml')
    args = parser.parse_args()
    run(args.config)
